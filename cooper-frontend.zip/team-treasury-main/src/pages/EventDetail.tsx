import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import {
  Wallet,
  ArrowLeft,
  Users,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Copy,
  Share2,
  Settings,
  CheckCircle2,
  Clock,
  AlertCircle,
  PieChart,
  TrendingUp,
  Calendar,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Mock event data
const mockEvent = {
  id: '1',
  name: 'Goa Trip 2024',
  code: 'GTR2024',
  description: 'Annual friends trip to Goa',
  startDate: '2024-02-15',
  endDate: '2024-02-20',
  totalBalance: 45000,
  status: 'active',
  members: [
    { id: '1', name: 'You', avatar: 'Y', balance: 7500, deposited: 7500 },
    { id: '2', name: 'Rahul', avatar: 'R', balance: 6200, deposited: 7500 },
    { id: '3', name: 'Priya', avatar: 'P', balance: 8100, deposited: 7500 },
    { id: '4', name: 'Amit', avatar: 'A', balance: 7500, deposited: 7500 },
    { id: '5', name: 'Sneha', avatar: 'S', balance: 8200, deposited: 7500 },
    { id: '6', name: 'Karan', avatar: 'K', balance: 7500, deposited: 7500 },
  ],
  expenses: [
    {
      id: '1',
      description: 'Hotel Booking - Resort Paradise',
      amount: 24000,
      category: 'Accommodation',
      paidBy: 'Rahul',
      splitType: 'equal',
      date: '2024-02-14',
      status: 'verified',
    },
    {
      id: '2',
      description: 'Dinner at Beach Shack',
      amount: 4500,
      category: 'Food',
      paidBy: 'You',
      splitType: 'equal',
      date: '2024-02-15',
      status: 'verified',
    },
    {
      id: '3',
      description: 'Water Sports Activities',
      amount: 9000,
      category: 'Activities',
      paidBy: 'Priya',
      splitType: 'custom',
      participants: ['You', 'Rahul', 'Amit', 'Karan'],
      date: '2024-02-16',
      status: 'pending',
    },
    {
      id: '4',
      description: 'Scooter Rental',
      amount: 3000,
      category: 'Transport',
      paidBy: 'Amit',
      splitType: 'equal',
      date: '2024-02-15',
      status: 'verified',
    },
  ],
  rules: {
    maxExpense: 10000,
    approvalThreshold: 15000,
  },
};

const categoryColors: Record<string, string> = {
  Accommodation: 'bg-blue-500/20 text-blue-400',
  Food: 'bg-orange-500/20 text-orange-400',
  Activities: 'bg-purple-500/20 text-purple-400',
  Transport: 'bg-green-500/20 text-green-400',
  Shopping: 'bg-pink-500/20 text-pink-400',
  Other: 'bg-gray-500/20 text-gray-400',
};

export default function EventDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<'expenses' | 'members' | 'analytics'>('expenses');

  const totalSpent = mockEvent.expenses.reduce((acc, exp) => acc + exp.amount, 0);
  const yourShare = totalSpent / mockEvent.members.length;

  const copyCode = () => {
    navigator.clipboard.writeText(mockEvent.code);
    toast({
      title: 'Code copied!',
      description: 'Share this code with others to join.',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-display font-bold text-lg">{mockEvent.name}</h1>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>
                  {mockEvent.startDate} - {mockEvent.endDate}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={copyCode}>
              <Copy className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Share2 className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-6 py-8">
        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"
        >
          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg gradient-primary flex items-center justify-center">
                <Wallet className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pool Balance</p>
                <p className="text-2xl font-bold">₹{mockEvent.totalBalance.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Spent</p>
                <p className="text-2xl font-bold">₹{totalSpent.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-info" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Members</p>
                <p className="text-2xl font-bold">{mockEvent.members.length}</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-5 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center">
                <PieChart className="w-6 h-6 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Your Share</p>
                <p className="text-2xl font-bold">₹{yourShare.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Your Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card-glow p-6 rounded-xl mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <p className="text-muted-foreground mb-1">Your Remaining Balance</p>
              <p className="text-4xl font-display font-bold">
                ₹{mockEvent.members[0].balance.toLocaleString()}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <div className="w-full max-w-xs h-2 bg-background rounded-full overflow-hidden">
                  <div
                    className="h-full gradient-primary rounded-full"
                    style={{
                      width: `${(mockEvent.members[0].balance / mockEvent.members[0].deposited) * 100}%`,
                    }}
                  />
                </div>
                <span className="text-sm text-muted-foreground">
                  {Math.round((mockEvent.members[0].balance / mockEvent.members[0].deposited) * 100)}%
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <Link to={`/events/${id}/expense`}>
                <Button variant="gradient" size="lg">
                  <Plus className="w-5 h-5" />
                  Add Expense
                </Button>
              </Link>
              <Button variant="outline" size="lg">
                <ArrowUpRight className="w-5 h-5" />
                Top Up
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-border">
          {(['expenses', 'members', 'analytics'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium capitalize transition-colors relative ${
                activeTab === tab
                  ? 'text-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 gradient-primary"
                />
              )}
            </button>
          ))}
        </div>

        {/* Expenses Tab */}
        {activeTab === 'expenses' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            {mockEvent.expenses.map((expense, index) => (
              <motion.div
                key={expense.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-card p-5 rounded-xl hover-lift cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
                      <ArrowDownRight className="w-6 h-6 text-destructive" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{expense.description}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>Paid by {expense.paidBy}</span>
                        <span>•</span>
                        <span>{expense.date}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        categoryColors[expense.category] || categoryColors.Other
                      }`}
                    >
                      {expense.category}
                    </span>
                    <div className="text-right">
                      <p className="font-bold text-lg">₹{expense.amount.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">
                        {expense.splitType === 'equal' ? 'Split equally' : 'Custom split'}
                      </p>
                    </div>
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        expense.status === 'verified'
                          ? 'bg-success/10 text-success'
                          : 'bg-warning/10 text-warning'
                      }`}
                    >
                      {expense.status === 'verified' ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <Clock className="w-4 h-4" />
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Members Tab */}
        {activeTab === 'members' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {mockEvent.members.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-card p-5 rounded-xl"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full gradient-primary flex items-center justify-center text-lg font-bold text-primary-foreground">
                    {member.avatar}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">
                      {member.name}
                      {member.id === '1' && (
                        <span className="ml-2 text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                          You
                        </span>
                      )}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Deposited: ₹{member.deposited.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Balance</p>
                    <p className="text-xl font-bold">₹{member.balance.toLocaleString()}</p>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        member.balance / member.deposited > 0.3
                          ? 'gradient-primary'
                          : 'bg-warning'
                      }`}
                      style={{ width: `${(member.balance / member.deposited) * 100}%` }}
                    />
                  </div>
                  {member.balance / member.deposited <= 0.3 && (
                    <div className="flex items-center gap-1 mt-2 text-warning text-xs">
                      <AlertCircle className="w-3 h-3" />
                      <span>Low balance - consider topping up</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            <div className="glass-card p-6 rounded-xl">
              <h3 className="font-display font-semibold text-lg mb-4">Spending by Category</h3>
              <div className="space-y-4">
                {Object.entries(
                  mockEvent.expenses.reduce((acc, exp) => {
                    acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
                    return acc;
                  }, {} as Record<string, number>)
                ).map(([category, amount]) => (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-1">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-medium ${
                          categoryColors[category] || categoryColors.Other
                        }`}
                      >
                        {category}
                      </span>
                      <span className="font-medium">₹{amount.toLocaleString()}</span>
                    </div>
                    <div className="w-full h-2 bg-background rounded-full overflow-hidden">
                      <div
                        className="h-full gradient-primary rounded-full"
                        style={{ width: `${(amount / totalSpent) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-card p-6 rounded-xl">
              <h3 className="font-display font-semibold text-lg mb-4">Event Rules</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="text-muted-foreground">Max Single Expense</span>
                  <span className="font-semibold">
                    ₹{mockEvent.rules.maxExpense.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="text-muted-foreground">Approval Required Above</span>
                  <span className="font-semibold">
                    ₹{mockEvent.rules.approvalThreshold.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}
