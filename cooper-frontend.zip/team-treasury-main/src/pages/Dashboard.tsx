import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store/authStore';
import {
  Wallet,
  Plus,
  Users,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Bell,
  Settings,
  LogOut,
  Calendar,
  Copy,
  ChevronRight,
  PieChart,
} from 'lucide-react';

// Mock data for demo
const mockEvents = [
  {
    id: '1',
    name: 'Goa Trip 2024',
    members: 6,
    totalBalance: 45000,
    yourBalance: 7500,
    status: 'active',
    startDate: '2024-02-15',
    endDate: '2024-02-20',
  },
  {
    id: '2',
    name: 'Office Party',
    members: 12,
    totalBalance: 24000,
    yourBalance: 2000,
    status: 'active',
    startDate: '2024-02-25',
    endDate: '2024-02-25',
  },
  {
    id: '3',
    name: 'Weekend Camping',
    members: 4,
    totalBalance: 0,
    yourBalance: 0,
    status: 'completed',
    startDate: '2024-01-10',
    endDate: '2024-01-12',
  },
];

const recentActivity = [
  { id: '1', type: 'expense', description: 'Hotel Booking', amount: 12000, event: 'Goa Trip 2024', time: '2h ago' },
  { id: '2', type: 'deposit', description: 'Rahul deposited', amount: 5000, event: 'Goa Trip 2024', time: '4h ago' },
  { id: '3', type: 'expense', description: 'Dinner at Beach Shack', amount: 3500, event: 'Goa Trip 2024', time: '6h ago' },
  { id: '4', type: 'deposit', description: 'You deposited', amount: 7500, event: 'Goa Trip 2024', time: '1d ago' },
];

export default function Dashboard() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const totalBalance = mockEvents.reduce((acc, event) => acc + event.yourBalance, 0);
  const activeEvents = mockEvents.filter((e) => e.status === 'active').length;

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
              <Wallet className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-display font-bold">Cooper</span>
          </Link>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
            </Button>

            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition-colors"
              >
                <div className="w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                  {user?.name?.charAt(0) || 'U'}
                </div>
                <span className="hidden md:block font-medium">{user?.name || 'User'}</span>
              </button>

              {showDropdown && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute right-0 mt-2 w-48 glass-card rounded-xl py-2 shadow-xl"
                >
                  <Link
                    to="/profile"
                    className="flex items-center gap-2 px-4 py-2 hover:bg-accent transition-colors"
                  >
                    <Settings className="w-4 h-4" />
                    <span>Settings</span>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 px-4 py-2 w-full hover:bg-accent transition-colors text-destructive"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Log out</span>
                  </button>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-6 py-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-display font-bold mb-2">
            Welcome back, <span className="gradient-text">{user?.name?.split(' ')[0] || 'User'}</span>
          </h1>
          <p className="text-muted-foreground">
            Here's what's happening with your shared wallets.
          </p>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <div className="glass-card p-6 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <p className="text-muted-foreground">Your Total Balance</p>
              <div className="w-10 h-10 rounded-lg gradient-primary-subtle flex items-center justify-center">
                <Wallet className="w-5 h-5 text-primary" />
              </div>
            </div>
            <p className="text-3xl font-bold">₹{totalBalance.toLocaleString()}</p>
            <p className="text-sm text-success flex items-center gap-1 mt-2">
              <ArrowUpRight className="w-4 h-4" />
              Across all events
            </p>
          </div>

          <div className="glass-card p-6 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <p className="text-muted-foreground">Active Events</p>
              <div className="w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-info" />
              </div>
            </div>
            <p className="text-3xl font-bold">{activeEvents}</p>
            <p className="text-sm text-muted-foreground mt-2">
              {mockEvents.length - activeEvents} completed
            </p>
          </div>

          <div className="glass-card p-6 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <p className="text-muted-foreground">Personal Wallet</p>
              <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
                <PieChart className="w-5 h-5 text-warning" />
              </div>
            </div>
            <p className="text-3xl font-bold">₹15,000</p>
            <p className="text-sm text-muted-foreground mt-2">Security deposit</p>
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap gap-4 mb-8"
        >
          <Link to="/events/create">
            <Button variant="gradient" size="lg">
              <Plus className="w-5 h-5" />
              Create New Event
            </Button>
          </Link>
          <Button variant="outline" size="lg">
            <Copy className="w-5 h-5" />
            Join with Code
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Events List */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-2"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-display font-semibold">Your Events</h2>
              <Link to="/events" className="text-sm text-primary hover:underline">
                View all
              </Link>
            </div>

            <div className="space-y-4">
              {mockEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <Link to={`/events/${event.id}`}>
                    <div className="glass-card p-6 rounded-xl hover-lift cursor-pointer group">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div
                            className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                              event.status === 'active'
                                ? 'gradient-primary'
                                : 'bg-muted'
                            }`}
                          >
                            <Users className="w-6 h-6 text-primary-foreground" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
                              {event.name}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {event.members} members • {event.startDate}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Your Balance</p>
                            <p className="font-semibold text-lg">
                              ₹{event.yourBalance.toLocaleString()}
                            </p>
                          </div>
                          <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                      </div>

                      {event.status === 'active' && (
                        <div className="mt-4 pt-4 border-t border-border">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Total Pool</span>
                            <span className="font-medium">
                              ₹{event.totalBalance.toLocaleString()}
                            </span>
                          </div>
                          <div className="w-full h-2 bg-background-surface rounded-full mt-2 overflow-hidden">
                            <div
                              className="h-full gradient-primary rounded-full"
                              style={{
                                width: `${(event.yourBalance / event.totalBalance) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-display font-semibold">Recent Activity</h2>
            </div>

            <div className="glass-card rounded-xl p-4">
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        activity.type === 'deposit'
                          ? 'bg-success/10'
                          : 'bg-destructive/10'
                      }`}
                    >
                      {activity.type === 'deposit' ? (
                        <ArrowUpRight className="w-5 h-5 text-success" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-destructive" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{activity.description}</p>
                      <p className="text-xs text-muted-foreground">{activity.event}</p>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-semibold ${
                          activity.type === 'deposit'
                            ? 'text-success'
                            : 'text-destructive'
                        }`}
                      >
                        {activity.type === 'deposit' ? '+' : '-'}₹
                        {activity.amount.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link
                to="/activity"
                className="block text-center text-sm text-primary hover:underline mt-4 pt-4 border-t border-border"
              >
                View all activity
              </Link>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
